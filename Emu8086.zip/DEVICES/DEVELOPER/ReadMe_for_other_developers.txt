note:

several running instances of the same device on the same port can cause a device conflict.
prevention mechanism should be used to avoid running several instances of the same device application.
