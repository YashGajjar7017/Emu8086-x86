    
    
    EMU8086  - 8086 microprocessor and integrated disassembler
    
    
    REQUIREMENTS
    ============
    
    Administrative rights. 

    1024x768 or greater screen resolution.

    Windows XP compatibly mode is recommended.
    Compatibly mode must be applied to "EMU8086.exe" and to all virtual hardware devices.
    To minimize incompatibly problems, run all files as administrator.

    READ/WRITE access should be granted to files at these locations:
    C:\emu8086.io
    C:\emu8086.hw



    COPYRIGHTS
    ==========

    Portions Copyright 1997-2012 Barry Allyn.  All rights reserved.

    Flat Assembler	version 1.64
    Copyright (c) 1999-2012, Tomasz Grysztar.
    All rights reserved.
   
    COPYRIGHT (C) 2012 by EMU8086.COM ALL RIGHTS RESERVED. 
    
    
    CONTACT
    =======        


    info@emu8086.com    

    http://www.emu8086.com
    
        
    YURI MARGOLIN
    KFAR EZION 1/635
    JERUSALEM
    ISRAEL
    



    
    
