

These examples are designed for EMU8086
